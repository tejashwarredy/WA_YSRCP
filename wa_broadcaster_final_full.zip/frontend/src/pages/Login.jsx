import React, { useState } from 'react';
import axios from 'axios';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('admin@example.com');
  const [password, setPassword] = useState('password123');
  const [err, setErr] = useState(null);

  const submit = async () => {
    try {
      const r = await axios.post('/api/auth/login', { email, password });
      if (r.data && r.data.token) {
        localStorage.setItem('wa_token', r.data.token);
        axios.defaults.headers.common['Authorization'] = 'Bearer ' + r.data.token;
        onLogin();
      }
    } catch (e) {
      setErr(e.response?.data?.error || 'Login failed');
    }
  }

  return (
    <div style={{padding:20, fontFamily:'sans-serif'}}>
      <h2>Admin Login</h2>
      {err && <div style={{color:'red'}}>{err}</div>}
      <div>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" />
      </div>
      <div style={{marginTop:6}}>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" />
      </div>
      <div style={{marginTop:10}}>
        <button onClick={submit}>Login</button>
      </div>
    </div>
  );
}
