import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CreateCampaign from './CreateCampaign';
import Senders from './Senders';

export default function Dashboard({ onLogout }) {
  const [campaigns, setCampaigns] = useState([]);

  useEffect(()=> {
    axios.get('/api/campaigns').then(r=>setCampaigns(r.data)).catch(()=>setCampaigns([]));
  },[]);

  const logout = () => {
    localStorage.removeItem('wa_token');
    delete axios.defaults.headers.common['Authorization'];
    onLogout();
  }

  return (
    <div style={{padding:20, fontFamily:'sans-serif'}}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h2>Admin Dashboard</h2>
        <div>
          <button onClick={logout}>Logout</button>
        </div>
      </div>
      <div style={{display:'flex', gap:20, marginTop:10}}>
        <div style={{flex:1}}>
          <CreateCampaign />
        </div>
        <div style={{width:420}}>
          <h3>Recent Campaigns</h3>
          <div style={{maxHeight:600, overflow:'auto', border:'1px solid #eee', padding:8}}>
            {campaigns.map(c=>(
              <div key={c.id} style={{padding:8, borderBottom:'1px solid #f1f1f1'}}>
                <div><strong>#{c.id}</strong> {c.status} - {new Date(c.created_at).toLocaleString()}</div>
                <div style={{marginTop:6}}>{c.message && c.message.substring(0,200)}</div>
                <div style={{marginTop:6}}>
                  <a href="#" onClick={async (e)=>{ e.preventDefault(); const r = await axios.get('/api/campaigns/'+c.id+'/logs'); alert(JSON.stringify(r.data,null,2)); }}>View Logs</a>
                </div>
              </div>
            ))}
          </div>
          <div style={{marginTop:12}}>
            <h3>Senders</h3>
            <Senders />
          </div>
        </div>
      </div>
    </div>
  );
}
