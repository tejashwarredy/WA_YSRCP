import axios from 'axios';
import { useEffect, useState } from 'react';

export default function CreateCampaign() {
  const [groups, setGroups] = useState([]);
  const [selected, setSelected] = useState(new Set());
  const [message, setMessage] = useState('');
  const [file, setFile] = useState(null);
  const [sender, setSender] = useState('default');
  const [qrDataUrl, setQrDataUrl] = useState(null);
  const [qrStatus, setQrStatus] = useState(null);
  const [showQr, setShowQr] = useState(false);
  const [sendersList, setSendersList] = useState([]);
  const [scheduleAt, setScheduleAt] = useState('');

  useEffect(() => {
    axios.get('/api/groups').then(r => setGroups(r.data)).catch(() => setGroups([]));
    axios.get('/api/senders').then(r => setSendersList(r.data)).catch(() => setSendersList([]));
  }, []);

  const toggle = id => {
    const s = new Set(selected);
    if (s.has(id)) s.delete(id); else s.add(id);
    setSelected(new Set(s));
  }

  const fetchQr = async (senderId='sender1') => {
    try {
      const r = await axios.get(`/api/qr/${senderId}`);
      if (r.data.ok) {
        setQrDataUrl(r.data.dataUrl);
        setQrStatus('qr');
      } else {
        setQrDataUrl(null);
        setQrStatus(r.data.message || 'not available');
      }
    } catch (e) {
      setQrDataUrl(null);
      setQrStatus('error');
    }
  }

  const fetchStatus = async (senderId='sender1') => {
    try {
      const r = await axios.get(`/api/sender-status/${senderId}`);
      if (r.data.ok) setQrStatus(r.data.status);
    } catch(e){}
  }

  const send = async () => {
    if (!selected.size) return alert('Select atleast one group');
    const form = new FormData();
    form.append('groups', JSON.stringify([...selected]));
    form.append('message', message);
    form.append('senderId', sender);
    if (file) form.append('file', file);
    if (scheduleAt) form.append('scheduleAt', new Date(scheduleAt).toISOString());
    const res = await axios.post('/api/send', form, { headers: {'Content-Type':'multipart/form-data'} });
    alert('Enqueued campaign: ' + (res.data.campaignId||'ok'));
  }

  return (
    <div style={{padding:20, fontFamily:'sans-serif', maxWidth:900}}>
      <h3>Create Campaign</h3>
      <div>
        <label>Sender: </label>
        {sendersList.length ? (
          <select value={sender} onChange={e=>setSender(e.target.value)}>
            {sendersList.map(s=> <option key={s.id} value={s.sender_key}>{s.label||s.sender_key}</option>)}
          </select>
        ) : (
          <select value={sender} onChange={e=>setSender(e.target.value)}>
            <option value="default">Default</option>
          </select>
        )}
        <button style={{marginLeft:10}} onClick={() => { setShowQr(true); fetchQr('sender1'); fetchStatus('sender1'); }}>Manage Sender / Scan QR</button>
      </div>
      <div style={{marginTop:10}}>
        <input placeholder="Search groups..." />
        <div style={{maxHeight:240, overflow:'auto', border:'1px solid #ddd', padding:8, marginTop:6}}>
          {groups.map(g => (
            <div key={g.id}>
              <label>
                <input type="checkbox" checked={selected.has(g.id)} onChange={()=>toggle(g.id)} />
                {' '}{g.group_name}
              </label>
            </div>
          ))}
        </div>
      </div>
      <div style={{marginTop:10}}>
        <textarea rows={6} style={{width:'100%'}} value={message} onChange={e=>setMessage(e.target.value)} placeholder="Message"/>
      </div>
      <div style={{marginTop:10}}>
        <input type="file" onChange={e=>setFile(e.target.files[0])} />
      </div>
      <div style={{marginTop:10}}>
        <label>Schedule at (optional): <input type="datetime-local" value={scheduleAt} onChange={e=>setScheduleAt(e.target.value)} /></label>
        <button style={{marginLeft:8}} onClick={send}>Send</button>
      </div>

      {showQr && (
        <div style={{
          position:'fixed', left:0, top:0, right:0, bottom:0, background:'rgba(0,0,0,0.5)',
          display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000
        }}>
          <div style={{background:'#fff', padding:20, borderRadius:8, maxWidth:520, width:'90%'}}>
            <h3>Scan QR for sender1</h3>
            <div style={{minHeight:200, display:'flex', alignItems:'center', justifyContent:'center', border:'1px dashed #ddd', padding:10}}>
              {qrDataUrl ? (
                <img src={qrDataUrl} alt="qr" style={{width:220,height:220}} />
              ) : (
                <div>
                  <p>QR not ready. Status: {qrStatus || 'unknown'}</p>
                  <button onClick={() => fetchQr('sender1')}>Refresh QR</button>
                </div>
              )}
            </div>
            <div style={{marginTop:10, display:'flex', justifyContent:'space-between'}}>
              <div>Status: <strong>{qrStatus || 'unknown'}</strong></div>
              <div>
                <button onClick={() => { setShowQr(false); setQrDataUrl(null); }}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
