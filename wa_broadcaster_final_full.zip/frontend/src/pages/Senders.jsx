import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Senders(){
  const [senders, setSenders] = useState([]);
  const [key, setKey] = useState('');
  const [label, setLabel] = useState('');

  useEffect(()=>{ fetch(); },[]);
  const fetch = async ()=> {
    try {
      const r = await axios.get('/api/senders');
      setSenders(r.data);
    } catch(e){ setSenders([]); }
  }

  const create = async ()=>{
    if(!key) return alert('sender key required');
    const r = await axios.post('/api/senders', { sender_key: key, label });
    setKey(''); setLabel('');
    fetch();
  }

  return (
    <div>
      <div style={{marginBottom:8}}>
        <input placeholder="Sender key (eg sender2)" value={key} onChange={e=>setKey(e.target.value)} />
        <input placeholder="Label" value={label} onChange={e=>setLabel(e.target.value)} style={{marginLeft:6}} />
        <button onClick={create} style={{marginLeft:6}}>Create</button>
      </div>
      <div>
        {senders.map(s=>(
          <div key={s.id} style={{padding:6, borderBottom:'1px solid #eee'}}>
            <strong>{s.label||s.sender_key}</strong><br/>
            <small>{s.sender_key}</small>
          </div>
        ))}
      </div>
    </div>
  );
}
