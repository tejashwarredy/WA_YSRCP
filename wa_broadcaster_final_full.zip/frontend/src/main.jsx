import React, { useState, useEffect } from 'react'
import { createRoot } from 'react-dom/client'
import axios from 'axios'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'

function App(){
  const [authed, setAuthed] = useState(false);
  useEffect(()=>{
    const token = localStorage.getItem('wa_token');
    if (token) {
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
      setAuthed(true);
    }
  },[]);
  return authed ? <Dashboard onLogout={()=>setAuthed(false)} /> : <Login onLogin={()=>setAuthed(true)} />
}

createRoot(document.getElementById('root')).render(<App />)
