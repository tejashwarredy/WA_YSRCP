#!/bin/bash
# Deployment script (Ubuntu 22.04) - basic automated steps
set -e
APP_DIR="/opt/wa-broadcaster"
USER="ubuntu"

echo "Updating and installing packages..."
sudo apt update && sudo apt install -y build-essential nginx git curl

# Node 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Redis & Postgres
sudo apt install -y redis-server postgresql postgresql-contrib

# PM2
sudo npm install -g pm2

# Clone application (assumes git has been configured)
if [ ! -d "$APP_DIR" ]; then
  sudo git clone https://your.repo.git $APP_DIR
fi
cd $APP_DIR

# Install backend deps and frontend deps
cd backend
npm install
cd ../frontend
npm install
npm run build
cd ..

# Setup env (copy .env.example to .env and edit)
if [ ! -f backend/.env ]; then
  cp backend/.env.example backend/.env
  echo "Please edit backend/.env with correct values"
fi

# Start processes with PM2
pm2 start pm2/ecosystem.config.js
pm2 save
pm2 startup systemd

# Configure Nginx (you should replace server_name)
sudo cp nginx/wa_broadcaster.conf /etc/nginx/sites-available/wa_broadcaster.conf
sudo ln -sf /etc/nginx/sites-available/wa_broadcaster.conf /etc/nginx/sites-enabled/wa_broadcaster.conf
sudo nginx -t && sudo systemctl reload nginx

echo "Deployment steps finished. Please configure SSL with certbot and update backend/.env"
