require('dotenv').config();
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const { Worker } = require('bullmq');
const Redis = require('ioredis');
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const mime = require('mime');
const clientProm = require('prom-client');

const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgresql://wa_user:pass@localhost:5432/wa_prod' });
const connection = new Redis(process.env.REDIS_URL || 'redis://127.0.0.1:6379');

const senderId = process.env.SENDER_ID || 'sender1';

const client = new Client({
  authStrategy: new LocalAuth({ clientId: senderId }),
  puppeteer: { headless: true, args: ['--no-sandbox','--disable-setuid-sandbox'] }
});

client.on('qr', async qr => {
  console.log('[QR]', qr);
  try {
    await connection.set(`wa:qr:${senderId}`, qr, 'EX', 300);
    await connection.set(`wa:status:${senderId}`, 'qr', 'EX', 300);
  } catch (e) {
    console.error('Redis set QR error', e);
  }
});

async function syncGroups(){
  try {
    console.log('syncGroups: fetching chats...');
    const chats = await client.getChats();
    let count = 0;
    for (const c of chats) {
      if (c.isGroup) {
        await pool.query(
          `INSERT INTO groups (group_name, wa_id, metadata) VALUES ($1,$2,$3)
            ON CONFLICT (wa_id) DO UPDATE SET group_name = EXCLUDED.group_name, metadata = EXCLUDED.metadata`,
          [c.name, c.id._serialized, JSON.stringify({ archived: c.archived || false })]
        );
        count++;
      }
    }
    console.log('syncGroups: synced', count, 'groups');
  } catch (err) {
    console.error('syncGroups error', err);
  }
}

client.on('ready', async () => {
  console.log('WhatsApp client ready');
  try {
    await connection.set(`wa:status:${senderId}`, 'ready');
    await connection.del(`wa:qr:${senderId}`);
  } catch(e){ console.error('Redis set ready error', e); }
  syncGroups().catch(err => console.error('initial syncGroups err', err));
  setInterval(()=>{ syncGroups().catch(err=>console.error('syncGroups err', err)); }, 30000);
});

client.on('auth_failure', msg => {
  console.error('Auth failure', msg);
  connection.set(`wa:status:${senderId}`, 'auth_failure');
});

client.initialize();

// Prometheus metrics
const collectDefaultMetrics = clientProm.collectDefaultMetrics;
collectDefaultMetrics();
const sentCounter = new clientProm.Counter({ name: 'wa_sent_messages_total', help: 'Total WA messages sent' });
const failedCounter = new clientProm.Counter({ name: 'wa_failed_messages_total', help: 'Total failed sends' });

const worker = new Worker('send-queue', async job => {
  if (job.name !== 'send-to-group') return;
  const { campaignId, groupId, message, mediaPath } = job.data;
  const { rows } = await pool.query('SELECT wa_id, group_name FROM groups WHERE id=$1', [groupId]);
  if (!rows.length) throw new Error('Group not found: ' + groupId);
  const waId = rows[0].wa_id;
  try {
    if (mediaPath) {
      const b64 = fs.readFileSync(mediaPath).toString('base64');
      const mtype = mime.getType(mediaPath) || 'application/octet-stream';
      const media = new MessageMedia(mtype, b64, path.basename(mediaPath));
      await client.sendMessage(waId, media, { caption: message || '' });
    } else {
      await client.sendMessage(waId, message || '');
    }
    await pool.query('INSERT INTO send_logs (campaign_id, group_id, status, detail) VALUES ($1,$2,$3,$4)', [campaignId, groupId, 'sent', null]);
    try{ sentCounter.inc(); }catch(e){}
  } catch (err) {
    console.error('send error', err);
    await pool.query('INSERT INTO send_logs (campaign_id, group_id, status, detail) VALUES ($1,$2,$3,$4)', [campaignId, groupId, 'failed', err.message]);
    try{ failedCounter.inc(); }catch(e){}
    throw err;
  }
}, { connection });

worker.on('failed', (job, err) => {
  console.error('Job failed', job.id, err.message);
});
