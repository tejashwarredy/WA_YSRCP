require('dotenv').config();
const express = require('express');
const multer = require('multer');
const { Queue } = require('bullmq');
const Redis = require('ioredis');
const { Pool } = require('pg');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const fs = require('fs');
const QRCode = require('qrcode');
const clientProm = require('prom-client');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.json());
app.use(helmet());
const apiLimiter = rateLimit({ windowMs: 60*1000, max: 120 });
app.use('/api/', apiLimiter);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 60 * 1024 * 1024 } });

const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgresql://wa_user:pass@localhost:5432/wa_prod' });
const connection = new Redis(process.env.REDIS_URL || 'redis://127.0.0.1:6379');
const sendQueue = new Queue('send-queue', { connection });

const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';

// basic health
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Auth endpoints
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email & password required' });
    const hash = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO admins (email, password_hash) VALUES ($1,$2) ON CONFLICT (email) DO NOTHING', [email, hash]);
    res.json({ ok: true });
  } catch (err) {
    console.error('register err', err);
    res.status(500).json({ error: 'registration failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const { rows } = await pool.query('SELECT id, email, password_hash FROM admins WHERE email=$1', [email]);
    if (!rows.length) return res.status(401).json({ error: 'invalid credentials' });
    const admin = rows[0];
    const match = await bcrypt.compare(password, admin.password_hash);
    if (!match) return res.status(401).json({ error: 'invalid credentials' });
    const token = jwt.sign({ id: admin.id, email: admin.email }, JWT_SECRET, { expiresIn: '12h' });
    res.json({ ok: true, token });
  } catch (err) {
    console.error('login err', err);
    res.status(500).json({ error: 'login failed' });
  }
});

function requireAuth(req, res, next){
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'no auth' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'bad auth' });
  const token = parts[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'invalid token' });
  }
}

// Groups list
app.get('/api/groups', requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, group_name, wa_id FROM groups ORDER BY group_name');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db error' });
  }
});

// Send API - multipart/form-data
app.post('/api/send', requireAuth, upload.single('file'), async (req, res) => {
  try {
    const { groups, message, senderId, scheduleAt } = req.body;
    let mediaPath = null;
    if (req.file) {
      const filename = Date.now() + '_' + req.file.originalname;
      mediaPath = path.join(__dirname, '..', 'uploads', filename);
      fs.mkdirSync(path.dirname(mediaPath), { recursive: true });
      fs.writeFileSync(mediaPath, req.file.buffer);
      // insert attachment record
      await pool.query('INSERT INTO attachments (path, filename, mimetype, size) VALUES ($1,$2,$3,$4)', [mediaPath, req.file.originalname, req.file.mimetype, req.file.size]);
    }
    const result = await pool.query(
      'INSERT INTO campaigns (message, media_path, sender_id, schedule_at, status) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [message || null, mediaPath, null, scheduleAt || null, 'scheduled']
    );
    const campaignId = result.rows[0].id;
    const groupList = JSON.parse(groups);
    for (const gid of groupList) {
      const delay = scheduleAt ? Math.max(new Date(scheduleAt) - Date.now(), 0) : 0;
      await sendQueue.add(
        'send-to-group',
        { campaignId, groupId: gid, message, mediaPath, senderId },
        { delay, attempts: 3, backoff: { type: 'exponential', delay: 2000 } }
      );
    }
    res.json({ success: true, campaignId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Protected endpoints
app.get('/api/campaigns', requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM campaigns ORDER BY created_at DESC LIMIT 100');
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'db error' }); }
});

app.get('/api/campaigns/:id/logs', requireAuth, async (req, res) => {
  try {
    const id = req.params.id;
    const { rows } = await pool.query('SELECT sl.*, g.group_name FROM send_logs sl LEFT JOIN groups g ON g.id=sl.group_id WHERE sl.campaign_id=$1 ORDER BY attempted_at DESC', [id]);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'db error' }); }
});

// Senders management
app.get('/api/senders', requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, sender_key, label, created_at FROM senders ORDER BY id');
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'db error' }); }
});

app.post('/api/senders', requireAuth, async (req, res) => {
  try {
    const { sender_key, label } = req.body;
    const { rows } = await pool.query('INSERT INTO senders (sender_key, label) VALUES ($1,$2) ON CONFLICT (sender_key) DO NOTHING RETURNING id, sender_key, label', [sender_key, label]);
    res.json(rows[0] || { sender_key, label });
  } catch (err) { res.status(500).json({ error: 'db error' }); }
});

// QR and sender status
app.get('/api/qr/:senderId', async (req, res) => {
  try {
    const senderId = req.params.senderId || 'sender1';
    const key = `wa:qr:${senderId}`;
    const qr = await connection.get(key);
    if (!qr) return res.json({ ok: false, message: 'QR not available' });
    const dataUrl = await QRCode.toDataURL(qr);
    res.json({ ok: true, qr, dataUrl });
  } catch (err) {
    console.error('qr endpoint error', err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/qr-svg/:senderId', async (req, res) => {
  try {
    const senderId = req.params.senderId || 'sender1';
    const key = `wa:qr:${senderId}`;
    const qr = await connection.get(key);
    if (!qr) return res.status(404).send('QR not available');
    const svg = await QRCode.toString(qr, { type: 'svg' });
    res.set('Content-Type', 'image/svg+xml');
    res.send(svg);
  } catch (err) {
    console.error('qr-svg error', err);
    res.status(500).send('error');
  }
});

app.get('/api/sender-status/:senderId', async (req, res) => {
  try {
    const senderId = req.params.senderId || 'sender1';
    const key = `wa:status:${senderId}`;
    const status = await connection.get(key);
    res.json({ ok: true, status: status || 'unknown' });
  } catch (err) {
    console.error('status endpoint error', err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Prometheus metrics endpoint
app.get('/metrics', async (req, res) => {
  try {
    res.set('Content-Type', clientProm.register.contentType);
    res.send(await clientProm.register.metrics());
  } catch (err) {
    res.status(500).send('error');
  }
});

// static uploads (optional)
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

server.listen(process.env.PORT || 3000, () => console.log('API listening on', process.env.PORT || 3000));
