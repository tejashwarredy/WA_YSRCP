-- 001_initial.sql
CREATE TABLE IF NOT EXISTS admins (
  id serial PRIMARY KEY,
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS senders (
  id serial PRIMARY KEY,
  sender_key text UNIQUE NOT NULL,
  label text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS groups (
  id serial PRIMARY KEY,
  group_name text,
  wa_id text UNIQUE,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS campaigns (
  id serial PRIMARY KEY,
  message text,
  media_path text,
  sender_id int REFERENCES senders(id),
  schedule_at timestamptz,
  status text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS send_logs (
  id serial PRIMARY KEY,
  campaign_id int REFERENCES campaigns(id),
  group_id int REFERENCES groups(id),
  status text,
  detail text,
  attempted_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS attachments (
  id serial PRIMARY KEY,
  path text,
  filename text,
  mimetype text,
  size int,
  uploaded_at timestamptz DEFAULT now()
);
