-- seed.sql
INSERT INTO senders (sender_key, label) VALUES ('sender1', 'Primary Sender') ON CONFLICT (sender_key) DO NOTHING;
-- admin password: password123 (change in production)
INSERT INTO admins (email, password_hash) VALUES ('admin@example.com', '$2a$10$xXo1nqP8sYqfXhJp4m9U6uQyF3sZ7Vgq9Kq0n1aB2cD3eF4gH5i6') ON CONFLICT (email) DO NOTHING;
