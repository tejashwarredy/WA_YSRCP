/**
 * Simple migration runner - runs SQL files in backend/db/migrations in lexicographic order.
 * Usage: node scripts/run_migrations.js
 */
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgresql://wa_user:pass@localhost:5432/wa_prod' });

async function run() {
  const dir = path.join(__dirname, '..', 'db', 'migrations');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  for (const f of files) {
    const p = path.join(dir, f);
    console.log('Running migration', f);
    const sql = fs.readFileSync(p, 'utf8');
    try {
      await pool.query(sql);
      console.log('Applied', f);
    } catch (err) {
      console.error('Error applying', f, err);
      process.exit(1);
    }
  }
  console.log('All migrations applied');
  await pool.end();
}
run();
