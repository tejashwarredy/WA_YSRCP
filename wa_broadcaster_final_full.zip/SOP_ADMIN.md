# SOP for Admins - WA Group Broadcaster

1. Add Sender (WhatsApp number)
   - On server, start a worker with unique SENDER_ID:
     ```
     SENDER_ID=sender2 pm2 start backend/worker.js --name worker-sender2
     ```
   - Check `pm2 logs worker-sender2` and scan the QR shown in logs or use Admin UI -> Manage Sender -> Scan QR.

2. Sync Groups
   - Worker auto-syncs groups on ready and every 30 seconds.
   - Confirm groups via Admin UI -> Create Campaign -> groups list.

3. Create Campaign
   - Login to Admin UI.
   - Select sender, choose groups via checkboxes, type message, attach file, and Send or Schedule.

4. Monitor & Retry
   - Campaign logs are available in Dashboard -> View Logs.
   - For failed sends, check worker logs and retry jobs from backend/admin endpoints (not yet implemented UI).

5. Backup WhatsApp Session
   - LocalAuth folders are under `~/.local-auth/<senderId>`.
   - Periodically copy to backup storage:
     ```
     cp -r /home/ubuntu/.local-auth/sender1 /backup/wa-sessions/sender1_$(date +%F)
     ```

6. Security
   - Change JWT_SECRET and admin passwords before production.
   - Ensure SSL and firewall rules are configured.
