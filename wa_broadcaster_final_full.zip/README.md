# WA Group Broadcaster - Project Skeleton (Full)

This repository skeleton contains:
- Backend (Node.js + Express + whatsapp-web.js)
- Worker process (BullMQ + Redis) to send messages
- Frontend (React + Vite) admin UI (Login, Dashboard, CreateCampaign)
- Docker Compose, PM2 ecosystem, nginx config sample
- Migrations & seed, migration runner script
- QR endpoints and QR-as-SVG for scanning
- Prometheus metrics endpoint (/metrics) and Grafana skeleton
- Deployment script and SOP

## Quick local dev
1. Start Redis & Postgres (docker-compose recommended)
   ```
   docker-compose up -d
   ```
2. Configure env: copy `backend/.env.example` to `backend/.env` and adjust.
3. Install npm deps:
   - Backend: `cd backend && npm install`
   - Frontend: `cd frontend && npm install`
4. Run migrations:
   - `cd backend && npm run migrate`
5. Start backend:
   - `cd backend && npm start`
6. Start worker:
   - `cd backend && SENDER_ID=sender1 npm run worker`
7. Start frontend:
   - `cd frontend && npm run dev`
8. Open frontend at http://localhost:5173

Notes:
- Scan QR via Manage Sender modal or GET /api/qr-svg/sender1
- Seed admin: admin@example.com / password123 (change in production)
- Use rate-limiting, multiple senders, and backup session folders.
