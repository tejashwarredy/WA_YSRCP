module.exports = {
  apps: [
    {
      name: 'wa-api',
      script: './backend/index.js',
      env: { NODE_ENV: 'production' }
    },
    {
      name: 'wa-worker-sender1',
      script: './backend/worker.js',
      env: { NODE_ENV: 'production', SENDER_ID: 'sender1' }
    }
  ]
}
